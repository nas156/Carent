create function cmp(hash1 bigint, hash2 bigint) returns double precision
    language plpgsql
as
$$
DECLARE
    temp bigint;
    result double precision;
    counter integer;
BEGIN
    result = 0;
    counter = 64;
    temp = int8xor(hash1, hash2);
    while counter>=0 loop
            result = result + int8and(temp, 1);
            temp = temp>>1;
            counter = counter-1;
        end loop;
    return 1 - result/64;
END;
$$;

alter function cmp(bigint, bigint) owner to postgres;

